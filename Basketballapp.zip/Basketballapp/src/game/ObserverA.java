package game;

public class ObserverA implements Observer {
    private int[] prediction;

    public ObserverA() {
        prediction = new int[] {0, 0};
    }

    public void update(int[] score) {
        prediction[0] += 10;
        prediction[1] += 5;
    }

    public int[] getPrediction() {
        return prediction;
    }
}
