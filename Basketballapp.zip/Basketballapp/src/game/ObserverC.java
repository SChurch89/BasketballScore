package game;

public class ObserverC implements Observer {
    private int[] prediction;

    public ObserverC() {
        prediction = new int[] {0, 0};
    }

    public void update(int[] score) {
        prediction[0] += 5;
        prediction[1] += 5;
    }

    public int[] getPrediction() {
        return prediction;
    }
}