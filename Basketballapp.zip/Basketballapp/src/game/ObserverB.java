package game;

public class ObserverB implements Observer {
    private int[] prediction;

    public ObserverB() {
        prediction = new int[] {0, 0};
    }

    public void update(int[] score) {
        prediction[0] += 5;
        prediction[1] += 10;
    }

    public int[] getPrediction() {
        return prediction;
    }
}
