package game;

import java.util.ArrayList;
import java.util.Scanner;
import java.util.Random;

public class BasketballApp {
    private static Scoring scoring;
    private static ObserverA observerA;
    private static ObserverB observerB;
    private static ObserverC observerC;
    private static Observer observer;
    private static Scanner scanner;
    private static Random random;

    public static void main(String[] args) {
        scoring = null;
        observerA = new ObserverA();
        observerB = new ObserverB();
        observerC = new ObserverC();
        observer = observerA;
        scanner = new Scanner(System.in);
        random = new Random();

        while (true) {
            System.out.println("Are you ready for some Basketball?");
            System.out.println("Please choose a number from the menu below");
            System.out.println("\n--- MENU ---");
            System.out.println("Press 1 to start a new game");
            System.out.println("Press 2 to start a prediction");
            System.out.println("Press 3 to print current score");
            System.out.println("Press 4 to print current prediction");
            System.out.println("Press 5 to print prediction stats");
            System.out.println("Press 6 to print score table");
            System.out.println("Press 7 to generate news piece title");
            System.out.println("Press 8 to exit");

            int choice = scanner.nextInt();

            if (choice == 1) {
                startNewGame();
            } else if (choice == 2) {
                predictQuarter();
            } else if (choice == 3) {
                printCurrentScore();
            } else if (choice == 4) {
                printCurrentPrediction();
            } else if (choice == 5) {
                printPredictionStats();
            } else if (choice == 6) {
                printScoreTable();
            } else if (choice == 7) {
                generateNewsPieceTitle(10,5);
            } else if (choice == 8) {
                System.exit(0);
            } else {
                System.out.println("Invalid choice. Please try again.");
            }
        }
    }

    private static void startNewGame() {
        // create new Scoring object with random teams
        int team1 = random.nextInt(100) + 1;
        int team2 = random.nextInt(100) + 1;
        scoring = new Scoring(team1, team2);
        scoring.registerObserver(observerA);
        scoring.registerObserver(observerB);
        scoring.registerObserver(observerC);
        System.out.println("A new game has started");
        System.out.println("Team 1 Score =  0");
        System.out.println("Team 2 Score = 0");
    }

    private static void predictQuarter() {
    	Random random = new Random();
        int team1Score = random.nextInt(26);
        int team2Score = random.nextInt(26);
        System.out.println("Team 1 Score = " + team1Score);
        System.out.println("Team 2 Score = " + team2Score);
        }
       

    private static void printCurrentScore() {
        if (scoring == null) {
            System.out.println("No game in progress.");
            return;
        }
        int[] score = scoring.getScore();
        int lastScoreTeam1 = Scoring.getLastScoreTeam1();
        int lastScoreTeam2 = scoring.getLastScoreTeam2();
        System.out.println("Current score: " + score[0] + " - " + score[1]);
        System.out.println("Last score for team 1: " + lastScoreTeam1);
        System.out.println("Last score for team 2: " + lastScoreTeam2);
    }

    private static void printCurrentPrediction() {
        if (scoring == null) {
            System.out.println("No game in progress.");
            return;
        }
        int[] prediction = observer.getPrediction();
        System.out.println("Current prediction: " + prediction[0] + " - " + prediction[1]);
    }

    private static void printPredictionStats() {
    	int team1Score = (int) (Math.random() * 100);
        int team2Score = (int) (Math.random() * 100);
        
        System.out.println("Prediction Stats:");
        System.out.println("Home Team Score: " + team1Score);
        System.out.println("Away Team Score: " + team2Score);
        
        if (team1Score == team2Score) {
            System.out.println("It's a tie!");
        } else if (team1Score > team2Score) {
            System.out.println("Home team is in the lead!");
        } else {
            System.out.println("Away team is here to play!!!");
        }
    }

    private static void printScoreTable() {
    	// Generate random scores for both teams for 4 quarters
        int[][] scores = new int[2][4];
        Random rand = new Random();
        for (int i = 0; i < 4; i++) {
            scores[0][i] = rand.nextInt(30) + 70; // generate a random score between 70 and 99 for team 1
            scores[1][i] = rand.nextInt(30) + 70; // generate a random score between 70 and 99 for team 2
        }

        // Print out the score table
        System.out.println("Quarter\t\tTeam 1\t\tTeam 2");
        for (int i = 0; i < 4; i++) {
            System.out.printf("Q%d\t\t%d\t\t%d\n", i + 1, scores[0][i], scores[1][i]);
        }
    }

    private static void generateNewsPieceTitle(int team1Score, int team2Score) {
    	if (team1Score == team2Score) {
            System.out.println("It's a tie!");
        } else if (team1Score > team2Score) {
            System.out.println("Home team wins!");
        } else {
            System.out.println("Away team wins!");
        }
    }

    private static void generateNewsPiece() {
        if (scoring == null) {
            System.out.println("No game in progress.");
            return;
        }

        int[] scores = scoring.getScore();
        int[] prediction = observer.getPrediction();

  
        System.out.println("The home team scored " + scores[0] + " points, and the away team scored " + scores[1] + " points.");
        System.out.println("Our prediction was " + prediction[0] + " - " + prediction[1] + ".");
        System.out.println("Stay tuned for more updates!");
    }
}
