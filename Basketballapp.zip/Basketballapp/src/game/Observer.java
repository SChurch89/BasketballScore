package game;

public interface Observer {
	 void update(int[] score);
	    int[] getPrediction();
}