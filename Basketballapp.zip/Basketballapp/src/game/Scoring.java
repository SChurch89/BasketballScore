package game;
import java.util.ArrayList;

public class Scoring {
    private int[] score;
    private ArrayList<Observer> observers;

    public Scoring(int team1, int team2) {
        score = new int[] {team1, team2};
        observers = new ArrayList<>();
    }

    public void registerObserver(Observer observer) {
        observers.add(observer);
    }

    public void removeObserver(Observer observer) {
        observers.remove(observer);
    }

    public void notifyObservers() {
        for (Observer observer : observers) {
            observer.update(score);
        }
    }

    public void updateScore(int team, int points) {
        score[team-1] += points;
        notifyObservers();
    }

    public int[] getScore() {
        return score;
    }

    static int getLastScoreTeam1() {
        Object scoring;
		if (scoring == null) {
            System.out.println("No game in progress.");
            return -1; // or throw an exception
        }
		 int[] scoreHistoryTeam1 = ((Object) scoring).getScoreHistoryTeam1();
		    if (scoreHistoryTeam1.length == 0) {
		        System.out.println("No score for team 1 yet.");
		        return -1; // or throw an exception
		    }
		    return scoreHistoryTeam1[scoreHistoryTeam1.length - 1];
		}
    static int getLastScoreTeam2() {
        Object scoring;
		if (scoring == null) {
            System.out.println("No game in progress.");
            return -1; // or throw an exception
        }
		 int[] scoreHistoryTeam2 = ((Object) scoring).getScoreHistoryTeam2();
		    if (scoreHistoryTeam2.length == 0) {
		        System.out.println("No score for team 2 yet.");
		        return -1; // or throw an exception
		    }
		    return scoreHistoryTeam2[scoreHistoryTeam2.length - 1];
		}
}

